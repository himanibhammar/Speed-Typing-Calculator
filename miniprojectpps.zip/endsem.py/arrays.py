# Online Python compiler (interpreter) to run Python onl
r=int(input())
c=int(input())
m=[]
for i in range(r):
    a=[]
    for i in range(c):
        a.append=int(input())
    m.append(a)
for i in range(r):
    for j in range(c):
        print(matrix[i][j],end=" ")
    print()